## DeepTMHMM - Predictions
Predicted topologies can be downloaded in [.gff3 format](TMRs.gff3) and [.3line format](predicted_topologies.3line)
### Job summary
```
Protein types:
TM:			215
SP:			3
GLOB:		356


Region types:
TMhelix:	1103
signal:		3
inside:		1116
outside:	561
TMbeta:		0
```
