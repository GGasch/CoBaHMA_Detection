## DeepTMHMM - Predictions
Predicted topologies can be downloaded in [.gff3 format](TMRs.gff3) and [.3line format](predicted_topologies.3line)
### Job summary
```
Protein types:
TM:			218
SP:			1
GLOB:		354


Region types:
TMhelix:	1092
signal:		1
inside:		1108
outside:	557
TMbeta:		0
```
