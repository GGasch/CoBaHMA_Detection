## DeepTMHMM - Predictions
Predicted topologies can be downloaded in [.gff3 format](TMRs.gff3) and [.3line format](predicted_topologies.3line)
### Job summary
```
Protein types:
TM:			231
SP+TM:		1
SP:			1
GLOB:		341


Region types:
TMhelix:	1159
signal:		2
inside:		1146
outside:	587
TMbeta:		0
```
